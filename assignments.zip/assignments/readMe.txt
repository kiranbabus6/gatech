Programming language used : Java (Realized it is easier to find python code snippets in web than Java, will have to learn Python soon). 

Please only use JDK 1.8, weka split options has a problem with JDK 1.9. It is an Oracle bug. 

How to run :  

Follow below steps : 

1) Download Eclipse preferably STS but any version which has maven plugin installed 

2) Unzip ml.zip in some location 

3) Import as maven project in eclipse and set it to pom.xml location 

4) It will download weka jars so make sure you are connected to internet 

5) There are two datasets  

Titanic survival 

Diabetes 

 

6) For Titanic survival dataset, set below variables in Constants.java in edu.gatech.ml.constants package 

 

This is training dataset file name : 

    public static final String TITANIC_TRAINING_DATA_SET_FILENAME="decision-train.arff"; 

This is testing dataset file name : 

    public static final String TITANIC_TESTING_DATA_SET_FILENAME="decision-test.arff"; 

This is datasets folder name : 

    public static final String TITANIC_FILES_PATH="C:/work/gatech/final_datasets/titanic/"; 

Final results of dataset using testing file using decision tree: 

    public static final String TITANIC_FINAL_RESULT_FILE_DECISION_TREE="final_result_decision_tree.arff"; 

Final results of dataset using KNN 

    public static final String TITANIC_FINAL_RESULT_FILE_KNN="final_result_knn.arff"; 

Number of nearest neighbours : 

    public static final Integer TITANIC_K_VALUE_FOR_KNN=5; 

Final results of dataset using NN 

    public static final String TITANIC_FINAL_RESULT_FILE_NN="final_result_nn.arff"; 

Final results of dataset using boosting with decision tree     

public static final String TITANIC_FINAL_RESULT_FILE_ADABOOST="final_result_decision_tree_with_boosting.arff"; 

Final results of dataset using SVM 

    public static final String TITANIC_FINAL_RESULT_FILE_SVM="final_result_SVM.arff"; 

 

7) For diabetes use below variables : 

Split the dataset into 64/36 with 64 for training and 36 for testing 

Percentage split : 

    public static final Integer DIABETES_PERCENT_SPLIT=64; 

Dataset filename : 

    public static final String DIABETES_DATA_SET_FILENAME="diabetes.arff"; 

Dataset files path : 

    public static final String DIABETES_FILES_PATH="C:/work/gatech/final_datasets/diabetes/"; 

Final results of decision tree 

    public static final String DIABETES_FINAL_RESULT_FILE_DECISION_TREE="final_result_decision_tree.arff"; 

Final results of KNN 

    public static final String DIABETES_FINAL_RESULT_FILE_KNN="final_result_knn.arff"; 

Number of nearest neighbours 

    public static final Integer DIABETES_K_VALUE_FOR_KNN=5; 

Final result of neural network 

    public static final String DIABETES_FINAL_RESULT_FILE_NN="final_result_nn.arff"; 

Final result of boosting 

    public static final String DIABETES_FINAL_RESULT_FILE_ADABOOST="final_result_decision_tree_with_boosting.arff"; 

Final result of support vector machines 

    public static final String DIABETES_FINAL_RESULT_FILE_SVM="final_result_SVM.arff"; 

 

7) Titanic algorithms are under package edu.gatech.ml.titanic 

8) diabetes algorithems are under package edu.gatech.ml.diabetes 

9) All final generated test datasets from this exercise are in final_datasets folder, however when you run they get created in folders mentioned above configuration.