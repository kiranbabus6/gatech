package edu.gatech.ml.diabetes;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Enumeration;

import edu.gatech.ml.constants.Constants;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.lazy.IBk;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
import weka.core.converters.ConverterUtils.DataSource;
public class Knn {
	/**
	 * This method is to load the data set.
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static Instances getDataSet(String fileName) throws Exception {
		/** the arffloader to load the arff file */
		ArffLoader loader = new ArffLoader();
		DataSource source;
		Instances dataSet = null;
			source = new DataSource(Constants.DIABETES_FILES_PATH+fileName);
			dataSet = source.getDataSet();
			dataSet.setClassIndex(dataSet.numAttributes() - 1);
			return dataSet;
	}

	public static Instances getDataSet(Instances inst, int start, int end) throws Exception {
		return new Instances(inst,start,end);
	}
	
	public void process() throws Exception {
		Instances dataSet = getDataSet(Constants.DIABETES_DATA_SET_FILENAME);
		dataSet.randomize(new java.util.Random(0));
		int trainSize = (int) Math.round(dataSet.numInstances() * Constants.DIABETES_PERCENT_SPLIT/100);
		int testSize = dataSet.numInstances() - trainSize;
		Instances trainingDataSet = getDataSet(dataSet,0,trainSize);
		Instances testingDataSet = getDataSet(dataSet,trainSize+1,testSize-1);
		Instances testingResult = new Instances(testingDataSet);
		Classifier ibk = new IBk(Constants.DIABETES_K_VALUE_FOR_KNN);		
		ibk.buildClassifier(trainingDataSet);
		 for (int i = 0; i < testingDataSet.numInstances(); i++) {
			   double clsLabel = ibk.classifyInstance(testingDataSet.instance(i));
			   testingResult.instance(i).setClassValue(clsLabel);
			 }
		 System.out.println("Generating KNN result file ...");
		 BufferedWriter writer = new BufferedWriter(
                 new FileWriter(Constants.DIABETES_FILES_PATH+Constants.DIABETES_FINAL_RESULT_FILE_KNN));
		 writer.write(testingResult.toString());
		 writer.newLine();
		 writer.flush();
		 writer.close();
		 System.out.println("Generated KNN result file at "+Constants.DIABETES_FILES_PATH+Constants.DIABETES_FINAL_RESULT_FILE_KNN);
	}
	
	public static void main(String args[])
	{
		Knn knn = new Knn();
		try {
			knn.process();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

}
}