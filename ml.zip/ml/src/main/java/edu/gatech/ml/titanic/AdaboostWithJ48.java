package edu.gatech.ml.titanic;

import java.io.BufferedWriter;
import java.io.FileWriter;

import edu.gatech.ml.constants.Constants;
import weka.classifiers.Evaluation;
import weka.classifiers.meta.AdaBoostM1;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
import weka.core.converters.ConverterUtils.DataSource;

public class AdaboostWithJ48 {

	public static Instances getDataSet(String fileName) throws Exception {
		/** the arffloader to load the arff file */
		DataSource source;
		Instances dataSet = null;
			source = new DataSource(Constants.TITANIC_FILES_PATH+fileName);
			dataSet = source.getDataSet();
			dataSet.setClassIndex(dataSet.numAttributes() - 1);
			return dataSet;
	}
	
	public void process() throws Exception {
		
		Instances trainingDataSet = getDataSet(Constants.TITANIC_TRAINING_DATA_SET_FILENAME);
		Instances testingDataSet = getDataSet(Constants.TITANIC_TESTING_DATA_SET_FILENAME);
		Instances testingResult = new Instances(testingDataSet);
		trainingDataSet.setClassIndex(trainingDataSet.numAttributes() - 1);
		AdaBoostM1 m1 = new AdaBoostM1();
		m1.setClassifier(new J48());
		m1.setNumIterations(20);
		m1.buildClassifier(trainingDataSet);
		 for (int i = 0; i < testingDataSet.numInstances(); i++) {
			   double clsLabel = m1.classifyInstance(testingDataSet.instance(i));
			   testingResult.instance(i).setClassValue(clsLabel);
			 }
		 BufferedWriter writer = new BufferedWriter(
                 new FileWriter(Constants.TITANIC_FILES_PATH+Constants.TITANIC_FINAL_RESULT_FILE_ADABOOST));
		 writer.write(testingResult.toString());
		 writer.newLine();
		 writer.flush();
		 writer.close();
		 System.out.println("Generated boosting with decision tree using adaboost result file at "+Constants.TITANIC_FILES_PATH+Constants.TITANIC_FINAL_RESULT_FILE_ADABOOST);
	}
	
	public static void main(String args[])
	{
		AdaboostWithJ48 adaboost = new AdaboostWithJ48();
		try {
			adaboost.process();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
