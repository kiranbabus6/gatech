package edu.gatech.ml.diabetes;

import java.io.BufferedWriter;
import java.io.FileWriter;

import edu.gatech.ml.constants.Constants;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.SMO;
import weka.core.Instances;
import weka.core.Utils;
import weka.core.converters.ArffLoader;
import weka.core.converters.ConverterUtils.DataSource;

public class SVM {

	public static Instances getDataSet(String fileName) throws Exception {
		/** the arffloader to load the arff file */
		ArffLoader loader = new ArffLoader();
		DataSource source;
		Instances dataSet = null;
			source = new DataSource(Constants.DIABETES_FILES_PATH+fileName);
			dataSet = source.getDataSet();
			dataSet.setClassIndex(dataSet.numAttributes() - 1);
			return dataSet;
	}

	public static Instances getDataSet(Instances inst, int start, int end) throws Exception {
		return new Instances(inst,start,end);
	}
	
	public void process() throws Exception {
		Instances dataSet = getDataSet(Constants.DIABETES_DATA_SET_FILENAME);
		dataSet.randomize(new java.util.Random(0));
		int trainSize = (int) Math.round(dataSet.numInstances() * Constants.DIABETES_PERCENT_SPLIT/100);
		int testSize = dataSet.numInstances() - trainSize;
		Instances trainingDataSet = getDataSet(dataSet,0,trainSize);
		Instances testingDataSet = getDataSet(dataSet,trainSize+1,testSize-1);
		Instances testingResult = new Instances(testingDataSet);
		SMO smo = new SMO();
		smo.setOptions(weka.core.Utils.splitOptions("-C 1.0 -L 0.0010 -P 1.0E-12 -N 0 -V -1 -W 1 -K \"weka.classifiers.functions.supportVector.PolyKernel -C 250007 -E 2.0\""));
		smo.buildClassifier(trainingDataSet);
		 for (int i = 0; i < testingDataSet.numInstances(); i++) {
			   double clsLabel = smo.classifyInstance(testingDataSet.instance(i));
			   testingResult.instance(i).setClassValue(clsLabel);
			 }
		 BufferedWriter writer = new BufferedWriter(
               new FileWriter(Constants.DIABETES_FILES_PATH+Constants.DIABETES_FINAL_RESULT_FILE_SVM));
		 writer.write(testingResult.toString());
		 writer.newLine();
		 writer.flush();
		 writer.close();
		 System.out.println("Generated NN result file at "+Constants.DIABETES_FILES_PATH+Constants.DIABETES_FINAL_RESULT_FILE_NN);

	}
	
	public static void main(String args[])
	{
		SVM svm = new SVM();
		try {
			svm.process();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
