package edu.gatech.ml.titanic;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Enumeration;

import edu.gatech.ml.constants.Constants;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.lazy.IBk;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
import weka.core.converters.ConverterUtils.DataSource;
public class Knn {
	/**
	 * This method is to load the data set.
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static Instances getDataSet(String fileName) throws Exception {
		/** the arffloader to load the arff file */
		ArffLoader loader = new ArffLoader();
		DataSource source;
		Instances dataSet = null;
			source = new DataSource(Constants.TITANIC_FILES_PATH+fileName);
			dataSet = source.getDataSet();
			dataSet.setClassIndex(dataSet.numAttributes() - 1);
			return dataSet;
	}


	/**
	 * @param args
	 * @throws Exception 
	 */
	public void process() throws Exception {
		
		Instances trainingDataSet = getDataSet(Constants.TITANIC_TRAINING_DATA_SET_FILENAME);
		Instances testingDataSet = getDataSet(Constants.TITANIC_TESTING_DATA_SET_FILENAME);
		Instances testingResult = new Instances(testingDataSet);
		trainingDataSet.setClassIndex(trainingDataSet.numAttributes() - 1);
		//k - the number of nearest neighbors to use for prediction
		Classifier ibk = new IBk(Constants.TITANIC_K_VALUE_FOR_KNN);		
		ibk.buildClassifier(trainingDataSet);
		 for (int i = 0; i < testingDataSet.numInstances(); i++) {
			   double clsLabel = ibk.classifyInstance(testingDataSet.instance(i));
			   testingResult.instance(i).setClassValue(clsLabel);
			 }
		 System.out.println("Generating KNN result file ...");
		 BufferedWriter writer = new BufferedWriter(
                 new FileWriter(Constants.TITANIC_FILES_PATH+Constants.TITANIC_FINAL_RESULT_FILE_KNN));
		 writer.write(testingResult.toString());
		 writer.newLine();
		 writer.flush();
		 writer.close();
		 System.out.println("Generated KNN result file at "+Constants.TITANIC_FILES_PATH+Constants.TITANIC_FINAL_RESULT_FILE_KNN);
	}
	
	public static void main(String args[])
	{
		Knn knn = new Knn();
		try {
			knn.process();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

}
}