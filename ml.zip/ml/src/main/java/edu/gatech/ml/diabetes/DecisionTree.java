package edu.gatech.ml.diabetes;
import java.io.BufferedWriter;
import java.io.FileWriter;

import edu.gatech.ml.constants.Constants;
import weka.classifiers.evaluation.Evaluation;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class DecisionTree {

	public Instances getDataSet(String fileName) throws Exception {
		DataSource source;
		Instances dataSet = null;
			source = new DataSource(Constants.DIABETES_FILES_PATH+fileName);
			dataSet = source.getDataSet();
			dataSet.setClassIndex(dataSet.numAttributes() - 1);
			return dataSet;
	}

	public static Instances getDataSet(Instances inst, int start, int end) throws Exception {
		return new Instances(inst,start,end);
	}
	
	public void process() throws Exception {
		Instances dataSet = getDataSet(Constants.DIABETES_DATA_SET_FILENAME);
		dataSet.randomize(new java.util.Random(0));
		int trainSize = (int) Math.round(dataSet.numInstances() * Constants.DIABETES_PERCENT_SPLIT/100);
		int testSize = dataSet.numInstances() - trainSize;
		Instances trainingDataSet = getDataSet(dataSet,0,trainSize);
		Instances testingDataSet = getDataSet(dataSet,trainSize+1,testSize-1);
		Instances testingResult = new Instances(testingDataSet);
		System.out.println("Generating J48 decision tree results ...");
		/** Classifier here is Linear Regression */
		J48 j48 = new J48();
		j48.setOptions(weka.core.Utils.splitOptions("-U -M 2"));
		//building classifier
		j48.buildClassifier(trainingDataSet);
		//running on testingDataSet and predicting result
		 for (int i = 0; i < testingDataSet.numInstances(); i++) {
			   double clsLabel = j48.classifyInstance(testingDataSet.instance(i));
			   testingResult.instance(i).setClassValue(clsLabel);
			 }
		 BufferedWriter writer = new BufferedWriter(
                 new FileWriter(Constants.DIABETES_FILES_PATH+Constants.DIABETES_FINAL_RESULT_FILE_DECISION_TREE));
		 writer.write(testingResult.toString());
		 writer.newLine();
		 writer.flush();
		 writer.close();
		 System.out.println("Generated decision tree result file at "+Constants.DIABETES_FILES_PATH+Constants.DIABETES_FINAL_RESULT_FILE_DECISION_TREE);
	}
	
	public static void main(String args[])
	{
		DecisionTree decisionTree = new DecisionTree();
		try {
			decisionTree.process();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

