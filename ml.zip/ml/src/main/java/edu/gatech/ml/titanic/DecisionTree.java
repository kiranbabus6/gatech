package edu.gatech.ml.titanic;
import java.io.BufferedWriter;
import java.io.FileWriter;

import edu.gatech.ml.constants.Constants;
import weka.classifiers.Classifier;
import weka.classifiers.evaluation.Evaluation;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
import weka.core.converters.ConverterUtils.DataSource;

public class DecisionTree {

	public static Instances getDataSet(String fileName) throws Exception {

		/** the arffloader to load the arff file */
		ArffLoader loader = new ArffLoader();
		DataSource source;
		Instances dataSet = null;
			source = new DataSource(Constants.TITANIC_FILES_PATH+fileName);
			dataSet = source.getDataSet();
			dataSet.setClassIndex(dataSet.numAttributes() - 1);
			return dataSet;
	}


	public void process() throws Exception {

		Instances trainingDataSet = getDataSet(Constants.TITANIC_TRAINING_DATA_SET_FILENAME);
		Instances testingDataSet = getDataSet(Constants.TITANIC_TESTING_DATA_SET_FILENAME);
		Instances testingResult = new Instances(testingDataSet);
		System.out.println("Generating J48 decision tree results ...");
		/** Classifier here is Linear Regression */
		J48 j48 = new J48();
		j48.setOptions(weka.core.Utils.splitOptions("-U -M 2"));
		//building classifier
		j48.buildClassifier(trainingDataSet);
		//running on testingDataSet and predicting result
		 for (int i = 0; i < testingDataSet.numInstances(); i++) {
			   double clsLabel = j48.classifyInstance(testingDataSet.instance(i));
			   testingResult.instance(i).setClassValue(clsLabel);
			 }
		 BufferedWriter writer = new BufferedWriter(
                 new FileWriter(Constants.TITANIC_FILES_PATH+Constants.TITANIC_FINAL_RESULT_FILE_DECISION_TREE));
		 writer.write(testingResult.toString());
		 writer.newLine();
		 writer.flush();
		 writer.close();
		 System.out.println("Generated decision tree result file at "+Constants.TITANIC_FILES_PATH+Constants.TITANIC_FINAL_RESULT_FILE_DECISION_TREE);

	}
	
	public static void main(String args[])
	{
		DecisionTree decisionTree = new DecisionTree();
		try {
			decisionTree.process();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}

