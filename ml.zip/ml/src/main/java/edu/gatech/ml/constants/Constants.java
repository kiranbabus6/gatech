package edu.gatech.ml.constants;

public class Constants {
	
	/* Titanic Dataset */
	public static final String TITANIC_TRAINING_DATA_SET_FILENAME="decision-train.arff";
	public static final String TITANIC_TESTING_DATA_SET_FILENAME="decision-test.arff";
	public static final String TITANIC_FILES_PATH="C:/work/gatech/final_datasets/titanic/";
	public static final String TITANIC_FINAL_RESULT_FILE_DECISION_TREE="final_result_decision_tree.arff";
	public static final String TITANIC_FINAL_RESULT_FILE_KNN="final_result_knn.arff";
	public static final Integer TITANIC_K_VALUE_FOR_KNN=5;
	public static final String TITANIC_FINAL_RESULT_FILE_NN="final_result_nn.arff";
	public static final String TITANIC_FINAL_RESULT_FILE_ADABOOST="final_result_decision_tree_with_boosting.arff";
	public static final String TITANIC_FINAL_RESULT_FILE_SVM="final_result_SVM.arff";
	
	/* Diabetes Dataset */
	public static final Integer DIABETES_PERCENT_SPLIT=80;
	public static final String DIABETES_DATA_SET_FILENAME="diabetes.arff";
	public static final String DIABETES_FILES_PATH="C:/work/gatech/final_datasets/diabetes/";
	public static final String DIABETES_FINAL_RESULT_FILE_DECISION_TREE="final_result_decision_tree.arff";
	public static final String DIABETES_FINAL_RESULT_FILE_KNN="final_result_knn.arff";
	public static final Integer DIABETES_K_VALUE_FOR_KNN=5;
	public static final String DIABETES_FINAL_RESULT_FILE_NN="final_result_nn.arff";
	public static final String DIABETES_FINAL_RESULT_FILE_ADABOOST="final_result_decision_tree_with_boosting.arff";
	public static final String DIABETES_FINAL_RESULT_FILE_SVM="final_result_SVM.arff";
		
}
