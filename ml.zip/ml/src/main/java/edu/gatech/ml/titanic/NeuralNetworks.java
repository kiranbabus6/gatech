package edu.gatech.ml.titanic;

import java.io.BufferedWriter;
import java.io.FileWriter;

import edu.gatech.ml.constants.Constants;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Instances;
import weka.core.converters.ArffLoader;
import weka.core.converters.ConverterUtils.DataSource;

public class NeuralNetworks {

	public static Instances getDataSet(String fileName) throws Exception {
		/** the arffloader to load the arff file */
		ArffLoader loader = new ArffLoader();
		DataSource source;
		Instances dataSet = null;
			source = new DataSource(Constants.TITANIC_FILES_PATH+fileName);
			dataSet = source.getDataSet();
			dataSet.setClassIndex(dataSet.numAttributes() - 1);
			return dataSet;
	}
	
	public void process() throws Exception {
		
		Instances trainingDataSet = getDataSet(Constants.TITANIC_TRAINING_DATA_SET_FILENAME);
		Instances testingDataSet = getDataSet(Constants.TITANIC_TESTING_DATA_SET_FILENAME);
		Instances testingResult = new Instances(testingDataSet);
		trainingDataSet.setClassIndex(trainingDataSet.numAttributes() - 1);
		MultilayerPerceptron mlp = new MultilayerPerceptron();		
		mlp.setLearningRate(0.1);
		mlp.setMomentum(0.1);
		mlp.buildClassifier(trainingDataSet);
		 for (int i = 0; i < testingDataSet.numInstances(); i++) {
			   double clsLabel = mlp.classifyInstance(testingDataSet.instance(i));
			   testingResult.instance(i).setClassValue(clsLabel);
			 }
		 System.out.println("Generating NN multi layer perceptorn result file ...");
		 BufferedWriter writer = new BufferedWriter(
                 new FileWriter(Constants.TITANIC_FILES_PATH+Constants.TITANIC_FINAL_RESULT_FILE_NN));
		 writer.write(testingResult.toString());
		 writer.newLine();
		 writer.flush();
		 writer.close();
		 System.out.println("Generated NN result file at "+Constants.TITANIC_FILES_PATH+Constants.TITANIC_FINAL_RESULT_FILE_NN);
	}
	
	public static void main(String args[])
	{
		NeuralNetworks nn = new NeuralNetworks();
		try {
			nn.process();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

}
}
