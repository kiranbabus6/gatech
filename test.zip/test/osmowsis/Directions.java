package osmowsis;

public enum Directions {
	NORTH("north"),
	NORTHEAST("northeast"), 
	EAST("east"), 
	SOUTHEAST("southeast"),
	SOUTH("south"), 
	SOUTHWEST("southwest"), 
	WEST("west"),
	NORTHWEST("northwest");	
	
	public final String code;
	private Directions(String code)
	{
		this.code=code;
	}
}
