package osmowsis;

import java.util.Random;

public class LawnMower {
	
	private Integer lawnMoversCurrentXPos;
	private Integer lawnMoversCurrentYPos;
	private String lawnMowerCurrentDirection=Directions.NORTH.code;
	private String lawnMowerNextDirection=Directions.NORTH.code;
	private Integer currentScan=0;
	private Integer nextScan=0;
	private static Random randGenerator;
	public String move(String[] scanInput)
	{
		for(int i=0;i<scanInput.length;i++)
		{
			if(scanInput[i].equals(ScanCodes.GRASS.toString()))
				return getDirFromCode(i);
		}
		randGenerator = new Random();
		nextScan=randGenerator.nextInt(7);
		for(int i=0;i<scanInput.length;i++)
		{
			currentScan=nextScan;
			nextScan++;
			if(nextScan==8)
				nextScan=0;
			if(scanInput[currentScan].equals(ScanCodes.EMPTY.toString()))
			{
				return getDirFromCode(currentScan);
			}
		}
		return null;
	}
	
	private String getDirFromCode(int i)
	{
		switch(i)
		{
		case 0:
			return Directions.NORTH.code;
		case 1:
			return Directions.NORTHEAST.code;
		case 2:
			return Directions.EAST.code;
		case 3:
			return Directions.SOUTHEAST.code;
		case 4:
			return Directions.SOUTH.code;
		case 5:
			return Directions.SOUTHWEST.code;
		case 6:
			return Directions.WEST.code;
		case 7:
			return Directions.NORTHWEST.code;
		}
		return null;
		}
		

	public Integer getLawnMoversCurrentXPos() {
		return lawnMoversCurrentXPos;
	}

	public void setLawnMoversCurrentXPos(Integer lawnMoversCurrentXPos) {
		this.lawnMoversCurrentXPos = lawnMoversCurrentXPos;
	}

	public Integer getLawnMoversCurrentYPos() {
		return lawnMoversCurrentYPos;
	}

	public void setLawnMoversCurrentYPos(Integer lawnMoversCurrentYPos) {
		this.lawnMoversCurrentYPos = lawnMoversCurrentYPos;
	}

	public String getLawnMowerCurrentDirection() {
		return lawnMowerCurrentDirection;
	}

	public void setLawnMowerCurrentDirection(String lawnMowerCurrentDirection) {
		this.lawnMowerCurrentDirection = lawnMowerCurrentDirection;
	}

	public String getLawnMowerNextDirection() {
		return lawnMowerNextDirection;
	}

	public void setLawnMowerNextDirection(String lawnMowerNextDirection) {
		this.lawnMowerNextDirection = lawnMowerNextDirection;
	}
	
	
}
