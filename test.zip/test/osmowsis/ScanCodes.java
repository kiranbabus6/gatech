package osmowsis;

public enum ScanCodes {
	GRASS(0), 
	CRATER(1),
	MOWER(2), 
	EMPTY(3), 
	FENCE(4);
	public final Integer code;
	private ScanCodes(Integer code)
	{
		this.code=code;
	}
}
