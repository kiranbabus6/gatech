package osmowsis;

import java.io.File;
import java.util.Scanner;

public class Simulator {

	private Integer lawnWidth;
	private Integer lawnHeight;
	private Integer lawnMoversCount=1;
	private Integer lawnMoversXPos;
	private Integer lawnMoversYPos;
	private String lawnMowerInitialDirection=Directions.NORTH.code;
	private String lawnMowerPreviousDirection=Directions.NORTH.code;
	private String lawnMowerNextDirection=Directions.NORTH.code;
	private Integer cratersCount;
	private Integer[][] cratersXPos;
	private Integer[][] craterYPos;
	private Integer maxTurns;
	private Integer[][] lawnInfo;
	private Integer currentTurns=0;
	private Integer jobStatus=0;
	private Integer scanCount=0;
	private Integer totalSquares;
	private Integer totalGrassSquares;
	private Integer totalGrassSquaresCut=1;
	
	public void incTotalGrassSquaresCut()
	{
		totalGrassSquaresCut++;
	}
	
	public Integer getTotalGrassSquaresCut()
	{
		return totalGrassSquaresCut;
	}
	public Integer getTotalGrassSquares()
	{
		return totalGrassSquares;
	}
	public Integer getTotalSquares()
	{
		return totalSquares;
	}
	public void incScanCount()
	{
		scanCount++;
	}
	
	public Integer getScanCount()
	{
		return scanCount;
	}
	
	public void displayMoveResults(String moveDirection)
	{
		if(lawnMowerPreviousDirection.equals(moveDirection))
		{
//			System.out.println("move,1,"+moveDirection);
//			System.out.println("ok");
		}	
		else
		{
			System.out.println("move,0,"+moveDirection);
			System.out.println("ok");
		}	
	}
	
	
	public String[] scan()
	{
		System.out.println("scan");
		String[] scanOutput=new String[8];
		scanOutput[0] = getNorthScan();
		scanOutput[1] = getNorthEastScan();
		scanOutput[2] = getEastScan();
		scanOutput[3] = getSouthEastScan();
		scanOutput[4] = getSouthScan();
		scanOutput[5] = getSouthWestScan();
		scanOutput[6] = getWestScan();
		scanOutput[7] = getNorthWestScan();
		return scanOutput;
	}
	private String getNorthScan()
	{
			if(lawnMoversYPos==lawnHeight-1)
				return ScanCodes.FENCE.name();
			else
			{
			if(lawnInfo[lawnMoversXPos][lawnMoversYPos+1]==ScanCodes.CRATER.code)
				return ScanCodes.CRATER.name();
			if(lawnInfo[lawnMoversXPos][lawnMoversYPos+1]==ScanCodes.EMPTY.code)
				return ScanCodes.EMPTY.name();
			if(lawnInfo[lawnMoversXPos][lawnMoversYPos+1]==ScanCodes.GRASS.code)
				return ScanCodes.GRASS.name();
			if(lawnInfo[lawnMoversXPos][lawnMoversYPos+1]==ScanCodes.MOWER.code)
				return ScanCodes.MOWER.name();
			}
			return null;
	}
	
	private String getNorthEastScan()
	{
		if(lawnMoversYPos==lawnHeight-1 || lawnMoversXPos==lawnWidth-1)
			return ScanCodes.FENCE.name();
		else
		{
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos+1]==ScanCodes.CRATER.code)
			return ScanCodes.CRATER.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos+1]==ScanCodes.EMPTY.code)
			return ScanCodes.EMPTY.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos+1]==ScanCodes.GRASS.code)
			return ScanCodes.GRASS.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos+1]==ScanCodes.MOWER.code)
			return ScanCodes.MOWER.name();
		}
		return null;
	}
	
	private String getEastScan()
	{
		if(lawnMoversXPos==lawnWidth-1)
			return ScanCodes.FENCE.name();
		else
		{
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos]==ScanCodes.CRATER.code)
			return ScanCodes.CRATER.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos]==ScanCodes.EMPTY.code)
			return ScanCodes.EMPTY.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos]==ScanCodes.GRASS.code)
			return ScanCodes.GRASS.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos]==ScanCodes.MOWER.code)
			return ScanCodes.MOWER.name();
		}
		return null;
	}

	private String getSouthEastScan()
	{
		if(lawnMoversXPos==lawnWidth-1||lawnMoversYPos==0)
			return ScanCodes.FENCE.name();
		else
		{
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos-1]==ScanCodes.CRATER.code)
			return ScanCodes.CRATER.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos-1]==ScanCodes.EMPTY.code)
			return ScanCodes.EMPTY.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos-1]==ScanCodes.GRASS.code)
			return ScanCodes.GRASS.name();
		if(lawnInfo[lawnMoversXPos+1][lawnMoversYPos-1]==ScanCodes.MOWER.code)
			return ScanCodes.MOWER.name();
		}
		return null;
	}
	
	private String getSouthScan()
	{
		if(lawnMoversYPos==0)
			return ScanCodes.FENCE.name();
		else
		{
		if(lawnInfo[lawnMoversXPos][lawnMoversYPos-1]==ScanCodes.CRATER.code)
			return ScanCodes.CRATER.name();
		if(lawnInfo[lawnMoversXPos][lawnMoversYPos-1]==ScanCodes.EMPTY.code)
			return ScanCodes.EMPTY.name();
		if(lawnInfo[lawnMoversXPos][lawnMoversYPos-1]==ScanCodes.GRASS.code)
			return ScanCodes.GRASS.name();
		if(lawnInfo[lawnMoversXPos][lawnMoversYPos-1]==ScanCodes.MOWER.code)
			return ScanCodes.MOWER.name();
		}
		return null;
	}
	
	private String getSouthWestScan()
	{
		if(lawnMoversXPos==0||lawnMoversYPos==0)
			return ScanCodes.FENCE.name();
		else
		{
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos-1]==ScanCodes.CRATER.code)
			return ScanCodes.CRATER.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos-1]==ScanCodes.EMPTY.code)
			return ScanCodes.EMPTY.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos-1]==ScanCodes.GRASS.code)
			return ScanCodes.GRASS.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos-1]==ScanCodes.MOWER.code)
			return ScanCodes.MOWER.name();
		}
		return null;
	}
	
	private String getWestScan()
	{
		if(lawnMoversXPos==0)
			return ScanCodes.FENCE.name();
		else
		{
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos]==ScanCodes.CRATER.code)
			return ScanCodes.CRATER.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos]==ScanCodes.EMPTY.code)
			return ScanCodes.EMPTY.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos]==ScanCodes.GRASS.code)
			return ScanCodes.GRASS.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos]==ScanCodes.MOWER.code)
			return ScanCodes.MOWER.name();
		}
		return null;
	}
	
	private String getNorthWestScan()
	{
		if(lawnMoversYPos==lawnHeight-1 || lawnMoversXPos==0)
			return ScanCodes.FENCE.name();
		else
		{
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos+1]==ScanCodes.CRATER.code)
			return ScanCodes.CRATER.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos+1]==ScanCodes.EMPTY.code)
			return ScanCodes.EMPTY.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos+1]==ScanCodes.GRASS.code)
			return ScanCodes.GRASS.name();
		if(lawnInfo[lawnMoversXPos-1][lawnMoversYPos+1]==ScanCodes.MOWER.code)
			return ScanCodes.MOWER.name();
		}
		return null;
	}
	
	public Integer getCurrentTurns()
	{
		return currentTurns;
	}
	public void setJobStatusToComplete()
	{
		this.jobStatus=1;
	}
	
	public Boolean getJobStatus()
	{
		if(jobStatus==0)
			return false;
			else
			return true;
	}
	
	public void turnIncrement()
	{
		currentTurns++;
	}
	public void setLawnInfo(String fileName)
	{
        final String DELIMITER = ",";

        try {
            Scanner takeCommand = new Scanner(new File(fileName));
            String[] tokens;
            int i, j, k;

            // read in the lawn information
            tokens = takeCommand.nextLine().split(DELIMITER);
            lawnWidth = Integer.parseInt(tokens[0]);
            tokens = takeCommand.nextLine().split(DELIMITER);
            lawnHeight = Integer.parseInt(tokens[0]);

            // generate the lawn information
            lawnInfo = new Integer[lawnWidth][lawnHeight];
            for (i = 0; i < lawnWidth; i++) {
                for (j = 0; j < lawnHeight; j++) {
                    lawnInfo[i][j] = ScanCodes.GRASS.code;
                }
            }

            // read in the lawnmower starting information
            tokens = takeCommand.nextLine().split(DELIMITER);
            int numMowers = Integer.parseInt(tokens[0]);
            for (k = 0; k < numMowers; k++) {
                tokens = takeCommand.nextLine().split(DELIMITER);
                lawnMoversXPos = Integer.parseInt(tokens[0]);
                lawnMoversYPos = Integer.parseInt(tokens[1]);
                lawnMowerInitialDirection = tokens[2];

                // mow the grass at the initial location
                lawnInfo[lawnMoversXPos][lawnMoversYPos] = ScanCodes.EMPTY.code;
            }

            // read in the crater information
            tokens = takeCommand.nextLine().split(DELIMITER);
            int numCraters = Integer.parseInt(tokens[0]);
            cratersCount=numCraters;
            for (k = 0; k < numCraters; k++) {
                tokens = takeCommand.nextLine().split(DELIMITER);

                // place a crater at the given location
                lawnInfo[Integer.parseInt(tokens[0])][Integer.parseInt(tokens[1])] = ScanCodes.CRATER.code;
            }
            tokens=takeCommand.nextLine().split(DELIMITER);
            maxTurns=Integer.parseInt(tokens[0]);
            takeCommand.close();
            totalSquares=lawnWidth*lawnHeight;
            totalGrassSquares=totalSquares-cratersCount;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println();
        }

	}
	
	public void updateLawnInfo(String dir)
	{
		lawnInfo[lawnMoversXPos][lawnMoversYPos]=ScanCodes.EMPTY.code;
		lawnMowerPreviousDirection=lawnMowerNextDirection;
		lawnMowerNextDirection=dir;
		displayMoveResults(dir);
		Integer[] inc = getIncrementCoordinates(dir);
		lawnMoversXPos=lawnMoversXPos+inc[0];
		lawnMoversYPos=lawnMoversYPos+inc[1];
		lawnInfo[lawnMoversXPos][lawnMoversYPos]=ScanCodes.MOWER.code;
		System.out.println("move,1,"+dir);
		System.out.println("ok");
		
	}
	
	
	private Integer[] getIncrementCoordinates(String dir)
	{
		Integer[] inc = new Integer[2];
		if(dir.equals(Directions.NORTH.code))
		{
			inc[0]=0; 
			inc[1]=1;
		}	
		
		if(dir.equals(Directions.NORTHEAST.code))
		{
			inc[0]=1;
			inc[1]=1;
		}
		if(dir.equals(Directions.EAST.code))
		{
			inc[0]=1;
			inc[1]=0;
		}
			
		if(dir.equals(Directions.SOUTHEAST.code))
		{
			inc[0]=1;
			inc[1]=-1;
		}
		if(dir.equals(Directions.SOUTH.code))
		{
			inc[0]=0;
			inc[1]=-1;
		}
		if(dir.equals(Directions.SOUTHWEST.code))
		{
			inc[0]=-1;
			inc[1]=-1;
		}
		if(dir.equals(Directions.WEST.code))
		{
			inc[0]=-1;
			inc[1]=0;
		}
		if(dir.equals(Directions.NORTHWEST.code))
		{
			inc[0]=-1;
			inc[1]=1;
		}
			return inc;
	}
	
	public String[] scan(Integer xPos, Integer yPos, String Direction)
	{
		return new String[8];
	}
	
    private void renderHorizontalBar(int size) {
        System.out.print(" ");
        for (int k = 0; k < size; k++) {
            System.out.print("-");
        }
        System.out.println("");
    }
	
	
    public void renderLawn() {
        int i, j;
        int charWidth = 2 * lawnWidth + 2;

        // display the rows of the lawn from top to bottom
        for (j = lawnHeight - 1; j >= 0; j--) {
            renderHorizontalBar(charWidth);

            // display the Y-direction identifier
            System.out.print(j);

            // display the contents of each square on this row
            for (i = 0; i < lawnWidth; i++) {
                System.out.print("|");

                // the mower overrides all other contents
                if (i == lawnMoversXPos & j == lawnMoversYPos) {
                    System.out.print("M");
                } else {
                    switch (lawnInfo[i][j]) {
                        case 3:
                            System.out.print(" ");
                            break;
                        case 0:
                            System.out.print("g");
                            break;
                        case 1:
                            System.out.print("c");
                            break;
                        default:
                            break;
                    }
                }
            }
            System.out.println("|");
        }
        renderHorizontalBar(charWidth);

        // display the column X-direction identifiers
        System.out.print(" ");
        for (i = 0; i < lawnWidth; i++) {
            System.out.print(" " + i);
        }
        System.out.println("");

        // display the mower's direction
        System.out.println("dir: " + lawnMowerNextDirection);
        System.out.println("");
    }

	
	public Integer getLawnMoversCount() {
		return lawnMoversCount;
	}
	public void setLawnMoversCount(Integer lawnMoversCount) {
		this.lawnMoversCount = lawnMoversCount;
	}
	public Integer getCratersCount() {
		return cratersCount;
	}
	public void setCratersCount(Integer cratersCount) {
		this.cratersCount = cratersCount;
	}
	public Integer getMaxTurns() {
		return maxTurns;
	}
	public void setMaxTurns(Integer maxTurns) {
		this.maxTurns = maxTurns;
	}

	public Integer getLawnMoversXPos() {
		return lawnMoversXPos;
	}

	public void setLawnMoversXPos(Integer lawnMoversXPos) {
		this.lawnMoversXPos = lawnMoversXPos;
	}

	public Integer getLawnMoversYPos() {
		return lawnMoversYPos;
	}

	public void setLawnMoversYPos(Integer lawnMoversYPos) {
		this.lawnMoversYPos = lawnMoversYPos;
	}

	public Integer[][] getCratersXPos() {
		return cratersXPos;
	}

	public void setCratersXPos(Integer[][] cratersXPos) {
		this.cratersXPos = cratersXPos;
	}

	public Integer[][] getCraterYPos() {
		return craterYPos;
	}

	public void setCraterYPos(Integer[][] craterYPos) {
		this.craterYPos = craterYPos;
	}

	public Integer getLawnWidth() {
		return lawnWidth;
	}

	public void setLawnWidth(Integer lawnWidth) {
		this.lawnWidth = lawnWidth;
	}

	public Integer getLawnHeight() {
		return lawnHeight;
	}

	public void setLawnHeight(Integer lawnHeight) {
		this.lawnHeight = lawnHeight;
	}

	public String getLawnMowerInitialDirection() {
		return lawnMowerInitialDirection;
	}

	public void setLawnMowerInitialDirection(String lawnMowerInitialDirection) {
		this.lawnMowerInitialDirection = lawnMowerInitialDirection;
	}

	public Integer[][] getLawnInfo() {
		return lawnInfo;
	}

	public void setLawnInfo(Integer[][] lawnInfo) {
		this.lawnInfo = lawnInfo;
	}
	
	
	
}
