package osmowsis;

public class Adapter {

		public void startLawnMowing(Simulator sim, LawnMower lw)
		{
//			sim.renderLawn();
			for(int i=0;i<sim.getMaxTurns();i++)
			{
//				int j=i+1;
//				System.out.println("current turn count: "+j);
//				System.out.println(sim.getTotalGrassSquaresCut()+"::"+sim.getTotalGrassSquares());
				if(sim.getTotalGrassSquaresCut()>=sim.getTotalGrassSquares())
				{
					sim.setJobStatusToComplete();
					break;
				}
				String[] scanOutput=sim.scan();
				i++;
				sim.turnIncrement();
				displayScanResults(scanOutput, sim.getCurrentTurns());
				if(isGreen(scanOutput))
				{
					sim.incTotalGrassSquaresCut();
				}
//					j=i+1;
//					System.out.println("current turn count: "+j);	
				String moveDirection=lw.move(scanOutput);
				sim.turnIncrement();
				sim.updateLawnInfo(moveDirection);
//				sim.renderLawn();
			}	
			

				System.out.println(sim.getTotalSquares()+","+sim.getTotalGrassSquares()+","+sim.getTotalGrassSquaresCut()+","+sim.getCurrentTurns());
//				sim.renderLawn();

		}
		
		private Boolean isGreen(String[] scanOutput)
		{
			for(String s: scanOutput)
			{
				if(s.equals(ScanCodes.GRASS.toString()))
					return true;
			}
			return false;
		}
		
		private void displayScanResults(String[] scanOutput, Integer currentTurnCount)
		{
//			System.out.println("current turn count "+currentTurnCount);
			System.out.println(String.join(",", scanOutput));
		}
}
