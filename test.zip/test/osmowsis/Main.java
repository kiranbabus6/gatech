package osmowsis;

public class Main {

	public static void main(String[] args)
	{
		if (args.length == 0) {
            System.out.println("ERROR: Test scenario file name not found. Exiting");
            System.exit(0);
        }
		Simulator sim = new Simulator();
		sim.setLawnInfo(args[0]);
		LawnMower lw = new LawnMower();
		Adapter adapter = new Adapter();
		adapter.startLawnMowing(sim, lw);
	}
}
